package patron_template;

// Clase base que define el esqueleto del algoritmo
public abstract class BebidaCalienteTemplate {
    
    
    // Template Method que define la secuencia de acciones
    public final void prepararBebida(){
        hervirAgua();
        prepararIngredientes();
        verterEnTaza();
        añadirCondimentos();   
    }
    
    
    // Métodos abstractos que deben ser implementados por las subclases
    protected abstract void prepararIngredientes();
    protected abstract void añadirCondimentos();
    
    
     // Método común para todas las subclases
    private void hervirAgua(){
        System.out.println("Hirviendo agua");
    }
    private void verterEnTaza(){
        System.out.println("Virtiendo en la taza");
    }
    
}

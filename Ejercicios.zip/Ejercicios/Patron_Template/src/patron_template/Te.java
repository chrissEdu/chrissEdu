
package patron_template;

//implementacion concreta para preparar el te
public class Te extends BebidaCalienteTemplate{

    @Override
    protected void prepararIngredientes() {
        System.out.println("Colocando bolsa de te");
    }

    @Override
    protected void añadirCondimentos() {
        System.out.println("Aniadiendo limon");
    }
    
}

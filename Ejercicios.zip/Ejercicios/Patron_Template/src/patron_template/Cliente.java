
package patron_template;


public class Cliente {

    public static void main(String[] args) {
        System.out.println("Preparando cafe");
        BebidaCalienteTemplate cafe = new Cafe();
        cafe.prepararBebida();
        
        System.out.println("\n    ******  *   *****");
        
        System.out.println("\nPreparando te");
        BebidaCalienteTemplate te =  new Te();
        te.prepararBebida();
   }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patron_template;

//Implementacion comcreta para preparar el café
public class Cafe extends BebidaCalienteTemplate{

    @Override
    protected void prepararIngredientes() {
        System.out.println("Moliendo el café");
    }

    @Override
    protected void añadirCondimentos() {
        System.out.println("Aniadiendo azucar y leche");
    }
    
}

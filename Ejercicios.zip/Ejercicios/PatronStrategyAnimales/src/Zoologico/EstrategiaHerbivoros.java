/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Zoologico;

/**
 *
 * @author ran23
 */
public class EstrategiaHerbivoros implements EstrategiaAnimal {
    String nombre;
    String descripcion;

    public EstrategiaHerbivoros(String descripcion, String nombre) {
        this.descripcion = descripcion;
        this.nombre = nombre;
    }

    @Override
    public void comida() {
        System.out.println("Dejando una racion de hierbas en la jaula de: " + nombre + " ya que " + descripcion);
    }

    @Override
    public void agua() {
        System.out.println("Poniendo agua en la jaula de: "+ nombre );
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Zoologico;

/**
 *
 * @author ran23
 */
public class CuidaroZoologico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        EstrategiaAnimal estrategiaLeon = new EstrategiaCarnivoro(" es un animal que se alimenta de carne cruda.","Leon");
        EstrategiaAnimal estrategiaVaca = new EstrategiaHerbivoros(" es un animal que se alimenta de plantas.","Vaca");
        EstrategiaAnimal estrategiaCerdo = new EstrategiaOmnivoros(" es un animal que se alimenta de plantas y carne(come todo).", "Cerdo");
        
        IniciaEstrategiasAnimal iniciaEstrategiasAnimal = new IniciaEstrategiasAnimal(estrategiaLeon);
        iniciaEstrategiasAnimal.alimentarAnimal();
        
        iniciaEstrategiasAnimal.setEstrategiaAnimal(estrategiaVaca);
        iniciaEstrategiasAnimal.alimentarAnimal();
        iniciaEstrategiasAnimal.ponerAgua();
        
        iniciaEstrategiasAnimal.setEstrategiaAnimal(estrategiaCerdo);
        iniciaEstrategiasAnimal.alimentarAnimal();
    }
    
}

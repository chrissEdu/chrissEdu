/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Zoologico;

/**
 *
 * @author ran23
 */
public class EstrategiaCarnivoro implements EstrategiaAnimal {
    String nombre;
    String descripcion;

    public EstrategiaCarnivoro(String descripcion, String nombre) {
        this.descripcion = descripcion;
        this.nombre = nombre;
        
    }

    @Override
    public void comida() {
        System.out.println("Dejando una racion de carne en la jaula de: " + nombre + " ya que " + descripcion);
    }

    @Override
    public void agua() {
        System.out.println("Poniendo agua en la jaula de: "+ nombre );
    }

}
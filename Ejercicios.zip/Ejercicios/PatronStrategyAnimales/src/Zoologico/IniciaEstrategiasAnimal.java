/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Zoologico;

/**
 *
 * @author ran23
 */
public class IniciaEstrategiasAnimal {
    EstrategiaAnimal estrategiaAnimal;
    

    public IniciaEstrategiasAnimal(EstrategiaAnimal estrategiaAnimal) {
        this.estrategiaAnimal = estrategiaAnimal;
       
    }

    public void setEstrategiaAnimal(EstrategiaAnimal estrategiaAnimal) {
        this.estrategiaAnimal = estrategiaAnimal;
    }
    
    public void alimentarAnimal(){
        estrategiaAnimal.comida();
        System.out.println("Animal alimentado");
    }
    
    public void ponerAgua(){
        estrategiaAnimal.agua();
        System.out.println("Animal con agua...");
    }
}

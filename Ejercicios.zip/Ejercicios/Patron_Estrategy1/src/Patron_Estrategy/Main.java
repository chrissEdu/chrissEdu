
package Patron_Estrategy;

public class Main {

    public static void main(String[] args) {
        IPatronEstrategy pagoPayPal = new PagoPayPal("chris@gmail.com");
        IPatronEstrategy pagoTarjeta = new PagoTarjeta("22/01/2023", "Christopher", "Paucar", "964");
        IPatronEstrategy pagoEfectivo = new PagoEfectivo("Christopher");
        
        IniciarEstrategia iniciarEstrategia = new IniciarEstrategia(pagoPayPal);
        iniciarEstrategia.procesarOrden(250);
        System.out.println("\n          ***     *     ***\n");
        iniciarEstrategia.setIpatronEstrategy(pagoTarjeta);
        iniciarEstrategia.procesarOrden(500);
        System.out.println("\n           ***     *     ***\n");
        iniciarEstrategia.setIpatronEstrategy(pagoEfectivo);
        iniciarEstrategia.procesarOrden(230);
        System.out.println("\n           ***     *     ***\n");
    }
    
}

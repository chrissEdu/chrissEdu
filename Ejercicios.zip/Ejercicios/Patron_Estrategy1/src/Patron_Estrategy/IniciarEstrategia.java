
package Patron_Estrategy;
//instanciador de estrategia

public class IniciarEstrategia {
    public IPatronEstrategy ipatronEstrategy;

    public IniciarEstrategia(IPatronEstrategy ipatronEstrategy) {
        this.ipatronEstrategy = ipatronEstrategy;
    }

    public void setIpatronEstrategy(IPatronEstrategy ipatronEstrategy) {
        this.ipatronEstrategy = ipatronEstrategy;
    }
    
    public void procesarOrden(double cantidad){
        System.out.println("La orden ha sido procesada  por un valor de: "+cantidad);
        ipatronEstrategy.procesarPago(cantidad);
    }
}   

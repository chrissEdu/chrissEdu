package Patron_Estrategy;
//creacion de estrategia concreta
public class PagoPayPal implements IPatronEstrategy {

    String correo;

    public PagoPayPal(String correo) {
        this.correo = correo;
    }

    @Override
    public void procesarPago(double cantidad) {
        System.out.println("Procesando pago de: " + cantidad + " con la cuneta del PayPal del correo usuario " + correo);
    }

}

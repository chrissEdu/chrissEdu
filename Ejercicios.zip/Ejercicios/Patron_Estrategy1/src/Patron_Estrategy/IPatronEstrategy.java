
package Patron_Estrategy;
//interfaz
public interface IPatronEstrategy {
    void procesarPago(double cantidad);
}

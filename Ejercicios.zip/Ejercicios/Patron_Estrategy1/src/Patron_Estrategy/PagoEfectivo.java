
package Patron_Estrategy;

//creacion de estrategia concreta
public class PagoEfectivo implements IPatronEstrategy{
    String nombre;

    public PagoEfectivo(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void procesarPago(double cantidad) {
        System.out.println("Procesando el pago de: "+cantidad+" a nombre de: "+ nombre);
    }
       
}

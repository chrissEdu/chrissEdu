
package Patron_Estrategy;
//creacion de estrategia concreta
public class PagoTarjeta implements IPatronEstrategy{
    String fecha;
    String nombre;
    String apellido;
    String cvv;

    public PagoTarjeta(String fecha, String nombre, String apellido, String cvv) {
        this.fecha = fecha;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cvv = cvv;
    }
    
    @Override
    public void procesarPago(double cantidad) {
        System.out.println("Procesando el pago de: "+ cantidad + " con la tarjeta de credito de "+nombre);
    }
}

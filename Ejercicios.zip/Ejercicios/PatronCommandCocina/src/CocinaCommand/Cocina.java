/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CocinaCommand;

/**
 *
 * @author ran23
 */
public class Cocina {
    public void cocinar(String orden){
        System.out.println("Cocinando: "+ orden);
    }
    
    public void servir(String orden){
        System.out.println("El mesero ha servido: "+orden);
    }
}

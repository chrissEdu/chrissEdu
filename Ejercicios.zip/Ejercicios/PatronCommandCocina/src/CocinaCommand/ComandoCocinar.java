/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CocinaCommand;

/**
 *
 * @author ran23
 */
public class ComandoCocinar implements CocinaCommand{
    public Cocina kitchen;
    public String orden;

    public ComandoCocinar(Cocina kitchen, String orden) {
        this.kitchen = kitchen;
        this.orden = orden;
    }
    
    @Override
    public void execute() {
        kitchen.cocinar(orden);
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package CocinaCommand;

/**
 *
 * @author ran23
 */
public class RestauranteExe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Cocina kitchen = new  Cocina();
        IniciaComandos iniciaComandos = new IniciaComandos();
        
        CocinaCommand comandoCocinar = new ComandoCocinar(kitchen, "Pasta");
        CocinaCommand comandoServir = new ComandoServir(kitchen, "Pasta");
        
        
        
        iniciaComandos.setComandoCocinar(comandoCocinar);
        iniciaComandos.setComandoServir(comandoServir);
        
        iniciaComandos.ponerOrden();
        iniciaComandos.sirviendOrden();
    }
    
}

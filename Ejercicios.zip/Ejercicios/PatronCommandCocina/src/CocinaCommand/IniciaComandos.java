/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CocinaCommand;

/**
 *
 * @author ran23
 */
public class IniciaComandos {
    CocinaCommand comandoCocinar;
    CocinaCommand comandoServir;

    public void setComandoCocinar(CocinaCommand comandoCocinar) {
        this.comandoCocinar = comandoCocinar;
    }

    public void setComandoServir(CocinaCommand comandoServir) {
        this.comandoServir = comandoServir;
    }
    
    public void ponerOrden(){
        comandoCocinar.execute();
    }
    
    public void sirviendOrden(){
        comandoServir.execute();
    }
            
}

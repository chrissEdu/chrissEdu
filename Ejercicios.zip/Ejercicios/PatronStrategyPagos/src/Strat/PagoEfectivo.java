/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strat;

/**
 *
 * @author ran23
 */
public class PagoEfectivo implements EstrategiaPago {

    String nombre;

    public PagoEfectivo(String nombre) {
        this.nombre = nombre;

    }

    @Override
    public void procesarPago(double cantidad) {
        System.out.println("Se ha pagado la cantidad de: "+cantidad+ " a nombre de: "+ nombre);
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strat;

/**
 *
 * @author ran23
 */
public class IniciaEstrategias {
    public EstrategiaPago estrategiaPago;

    public IniciaEstrategias(EstrategiaPago estrategiaPago) {
        this.estrategiaPago = estrategiaPago;
    }

    public void setEstrategiaPago(EstrategiaPago estrategiaPago) {
        this.estrategiaPago = estrategiaPago;
    }
    
    public void procesarOrden(double cantidad){
        System.out.println("La orden ha sido porcesada por un valor de: "+ cantidad);
        estrategiaPago.procesarPago(cantidad);
    }
}

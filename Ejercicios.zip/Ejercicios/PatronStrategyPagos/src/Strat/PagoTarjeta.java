/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strat;

/**
 *
 * @author ran23
 */
public class PagoTarjeta implements EstrategiaPago{

    
    String fechaVence;
    String nombre;
    String apellido;
    String cvv;
    
    public PagoTarjeta(String fechaVence, String nombre, String apellido, String cvv) {
        this.fechaVence = fechaVence;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cvv = cvv;
    }

    @Override
    public void procesarPago(double cantidad) {
        System.out.println("Procesando pago de: "+ cantidad+ " con la tarjeta de credito de "+ nombre);
    }
    
    
}

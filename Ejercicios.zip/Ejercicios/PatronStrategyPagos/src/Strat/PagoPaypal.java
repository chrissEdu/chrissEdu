/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strat;

/**
 *
 * @author ran23
 */
public class PagoPaypal implements EstrategiaPago{
    String correo;

    public PagoPaypal(String correo) {
        this.correo = correo;
    }

    @Override
    public void procesarPago(double cantidad) {
        System.out.println("Procesando pago de: "+ cantidad+ " con la cuenta de Paypal del usuario "+ correo);
    }
    
    
}

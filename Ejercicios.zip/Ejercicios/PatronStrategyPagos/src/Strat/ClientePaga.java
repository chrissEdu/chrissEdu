/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Strat;

/**
 *
 * @author ran23
 */
public class ClientePaga {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        EstrategiaPago pagoPaypal = new PagoPaypal("ran236dy@gmail.com");
        EstrategiaPago pagoTarjeta = new PagoTarjeta("25/07", "Raul", "Ortiz", "934");
        EstrategiaPago pagoEfectivo = new PagoEfectivo("Cris");
        
        
        IniciaEstrategias iniciaEstrategias = new IniciaEstrategias(pagoTarjeta);
        
        iniciaEstrategias.procesarOrden(500);
        
        iniciaEstrategias.setEstrategiaPago(pagoPaypal);
        iniciaEstrategias.procesarOrden(200);
        
        iniciaEstrategias.setEstrategiaPago(pagoEfectivo);
        iniciaEstrategias.procesarOrden(30);
                
    }
    
}

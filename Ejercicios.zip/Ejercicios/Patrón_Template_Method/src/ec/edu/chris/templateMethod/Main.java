package ec.edu.chris.templateMethod;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Network network = null;
        System.out.print("Ingrese su nombre de usuario: ");
        String userName = reader.readLine();
        System.out.print("Ingrese su password: ");
        String password = reader.readLine();

        // Enter the message.
        System.out.print("Ingrese un mensaje: ");
        String message = reader.readLine();

        System.out.println("\nElegir la red social para publicar el mensaje.\n" +
                "1 - Facebook\n" +
                "2 - Twitter");
        int choice = Integer.parseInt(reader.readLine());

        // Crear el objeto de red adecuado y enviar el mensaje.
        if (choice == 1) {
            network = new Facebook(userName, password);
        } else if (choice == 2) {
            network = new Twitter(userName, password);
        }
        network.post(message);
    }
}

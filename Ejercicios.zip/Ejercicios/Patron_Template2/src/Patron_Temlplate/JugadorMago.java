
package Patron_Temlplate;

public class JugadorMago extends Jugador{

    @Override
    protected void seleccionarPersonaje() {
        System.out.println("Seleccionar Mago");
    }

    @Override
    protected void atacar() {
        System.out.println("Lanzar hechizo");
    }

    @Override
    protected void defender() {
        System.out.println("Crear barrera magica");
    }
    
}

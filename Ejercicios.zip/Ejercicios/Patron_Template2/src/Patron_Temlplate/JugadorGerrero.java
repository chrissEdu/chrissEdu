
package Patron_Temlplate;

public class JugadorGerrero extends Jugador{

    @Override
    protected void seleccionarPersonaje() {
        System.out.println("Seleccionar el perdonale");
    }

    @Override
    protected void atacar() {
        System.out.println("atacar con espada");
    }

    @Override
    protected void defender() {
        System.out.println("Defender con escudo");
    }
    
}


package Patron_Temlplate;


public abstract class Jugador {
    public final void jugar(){
        seleccionarPersonaje();
        atacar();
        defender();
        terminarPartido();
    }
    
    protected abstract void seleccionarPersonaje();
    protected abstract void atacar();
    protected abstract void defender();
    
    private void terminarPartido(){
        System.out.println("Partida finalizada");
    }
    
}

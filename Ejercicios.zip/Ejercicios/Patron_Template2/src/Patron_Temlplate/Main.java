
package Patron_Temlplate;


public class Main {
    public static void main(String[] args) {
        
        Jugador jugadorGuerrero = new JugadorGerrero();
        System.out.println("Jugador 1");
        jugadorGuerrero.jugar();
        System.out.println("\n  ***     *    ***\n");
        Jugador jugadorMago = new JugadorMago();
        System.out.println("Jugador 2");
        jugadorMago.jugar();
               
    }
}

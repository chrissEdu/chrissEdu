/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Com;

/**
 *
 * @author ran23
 */
public class CommanderExe {
    public static void main(String[] args) {
        // Crear instancias de los objetos relevantes
        Device tv = new TV();
        AudioDevice stereoSystem = new StereoSystem();

        // Crear instancias de comandos
        Command turnOnTV = new TurnOnCommand(tv);
        Command turnOffStereo = new TurnOffcommand(stereoSystem);
        Command volumeUpStereo = new VolumeUpCommand(stereoSystem);

        // Configurar el control remoto con comandos
        RemoteControl remoteControl = new RemoteControl();
        remoteControl.setCommand(turnOnTV);
        remoteControl.pressButton();

        remoteControl.setCommand(turnOffStereo);
        remoteControl.pressButton();

        remoteControl.setCommand(volumeUpStereo);
        remoteControl.pressButton();
    }
}

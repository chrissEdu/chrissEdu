/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Com;

/**
 *
 * @author ran23
 */
public class StereoSystem implements AudioDevice {
    @Override
    public void turnOn() {
        System.out.println("Encendiendo el sistema de sonido");
    }

    @Override
    public void turnOff() {
        System.out.println("Apagando el sistema de sonido");
    }

    @Override
    public void volumeUp() {
        System.out.println("Subiendo el volumen del sistema de sonido");
    }
}

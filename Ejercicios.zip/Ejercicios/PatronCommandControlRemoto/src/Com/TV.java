/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Com;

/**
 *
 * @author ran23
 */
public class TV implements Device {
    @Override
    public void turnOn() {
        System.out.println("Encendiendo el televisor");
    }

    @Override
    public void turnOff() {
        System.out.println("Apagando el televisor");
    }
}
